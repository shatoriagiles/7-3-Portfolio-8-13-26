package com.example.cs360inventory;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class InventoryActivity extends Activity {
    private static final int SMS_PERMISSION_REQUEST = 301;
    private static final int LOW_STOCK_THRESHOLD = 2;
    private DatabaseHelper databaseHelper;
    private GridLayout inventoryGrid;
    private EditText itemNameInput;
    private EditText quantityInput;
    private Button addButton;
    private Button updateButton;
    private long userId;
    private long selectedItemId = -1;
    private String pendingAlertItem = "";
    private int pendingAlertQuantity = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        userId = getIntent().getLongExtra("userId", -1);
        if (userId < 0) {
            logOut();
            return;
        }

        databaseHelper = new DatabaseHelper(this);
        inventoryGrid = findViewById(R.id.inventoryGrid);
        itemNameInput = findViewById(R.id.itemNameInput);
        quantityInput = findViewById(R.id.quantityInput);
        addButton = findViewById(R.id.addButton);
        updateButton = findViewById(R.id.updateButton);
        Button cancelButton = findViewById(R.id.cancelButton);
        Button smsPermissionButton = findViewById(R.id.smsPermissionButton);
        Button logoutButton = findViewById(R.id.logoutButton);
        TextView welcomeText = findViewById(R.id.welcomeText);

        String username = databaseHelper.getUsername(userId);
        welcomeText.setText(username.isEmpty() ? "Inventory" : username + "'s Inventory");

        addButton.setOnClickListener(view -> addItem());
        updateButton.setOnClickListener(view -> updateItem());
        cancelButton.setOnClickListener(view -> clearEditor());
        smsPermissionButton.setOnClickListener(view -> requestSmsPermission());
        logoutButton.setOnClickListener(view -> logOut());

        updateButton.setEnabled(false);
        loadInventory();
    }

    private void addItem() {
        String name = itemNameInput.getText().toString().trim();
        Integer quantity = readQuantity();

        if (TextUtils.isEmpty(name) || quantity == null) {
            Toast.makeText(this, "Enter an item name and quantity.", Toast.LENGTH_SHORT).show();
            return;
        }

        long itemId = databaseHelper.addInventoryItem(userId, name, quantity);
        if (itemId < 0) {
            Toast.makeText(this, "Unable to add item.", Toast.LENGTH_SHORT).show();
            return;
        }

        triggerLowStockAlert(name, quantity);
        clearEditor();
        loadInventory();
    }

    private void updateItem() {
        if (selectedItemId < 0) {
            return;
        }

        String name = itemNameInput.getText().toString().trim();
        Integer quantity = readQuantity();
        if (TextUtils.isEmpty(name) || quantity == null) {
            Toast.makeText(this, "Enter an item name and quantity.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean updated = databaseHelper.updateInventoryItem(selectedItemId, userId, name, quantity);
        if (updated) {
            triggerLowStockAlert(name, quantity);
            Toast.makeText(this, "Item updated.", Toast.LENGTH_SHORT).show();
        }
        clearEditor();
        loadInventory();
    }

    private void deleteItem(InventoryItem item) {
        if (databaseHelper.deleteInventoryItem(item.getId(), userId)) {
            if (selectedItemId == item.getId()) {
                clearEditor();
            }
            loadInventory();
            Toast.makeText(this, "Item deleted.", Toast.LENGTH_SHORT).show();
        }
    }

    private Integer readQuantity() {
        String value = quantityInput.getText().toString().trim();
        if (value.isEmpty()) {
            return null;
        }
        try {
            int quantity = Integer.parseInt(value);
            return quantity >= 0 ? quantity : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void loadInventory() {
        inventoryGrid.removeAllViews();
        addHeaderCell("Item");
        addHeaderCell("Quantity");
        addHeaderCell("Edit");
        addHeaderCell("Delete");

        List<InventoryItem> items = databaseHelper.getInventoryItems(userId);
        if (items.isEmpty()) {
            TextView emptyText = createCell("No inventory items yet.");
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.columnSpec = GridLayout.spec(0, 4, 1f);
            params.width = 0;
            emptyText.setLayoutParams(params);
            inventoryGrid.addView(emptyText);
            return;
        }

        for (InventoryItem item : items) {
            TextView nameCell = createCell(item.getName());
            TextView quantityCell = createCell(String.valueOf(item.getQuantity()));
            Button editButton = createGridButton("Edit");
            Button deleteButton = createGridButton("Delete");

            editButton.setOnClickListener(view -> selectItem(item));
            deleteButton.setOnClickListener(view -> deleteItem(item));

            inventoryGrid.addView(nameCell);
            inventoryGrid.addView(quantityCell);
            inventoryGrid.addView(editButton);
            inventoryGrid.addView(deleteButton);
        }
    }

    private void addHeaderCell(String value) {
        TextView textView = createCell(value);
        textView.setTypeface(null, Typeface.BOLD);
        inventoryGrid.addView(textView);
    }

    private TextView createCell(String value) {
        TextView textView = new TextView(this);
        textView.setText(value);
        textView.setTextSize(15);
        textView.setPadding(12, 18, 12, 18);
        textView.setGravity(Gravity.CENTER_VERTICAL);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        params.width = 0;
        params.setMargins(2, 2, 2, 2);
        textView.setLayoutParams(params);
        textView.setBackgroundColor(0xFFFFFFFF);
        return textView;
    }

    private Button createGridButton(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        params.width = 0;
        params.setMargins(2, 2, 2, 2);
        button.setLayoutParams(params);
        return button;
    }

    private void selectItem(InventoryItem item) {
        selectedItemId = item.getId();
        itemNameInput.setText(item.getName());
        quantityInput.setText(String.valueOf(item.getQuantity()));
        addButton.setEnabled(false);
        updateButton.setEnabled(true);
        itemNameInput.requestFocus();
    }

    private void clearEditor() {
        selectedItemId = -1;
        itemNameInput.setText("");
        quantityInput.setText("");
        addButton.setEnabled(true);
        updateButton.setEnabled(false);
    }

    private void requestSmsPermission() {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS alerts are enabled.", Toast.LENGTH_SHORT).show();
            return;
        }
        requestPermissions(new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST);
    }

    private void triggerLowStockAlert(String itemName, int quantity) {
        if (quantity > LOW_STOCK_THRESHOLD) {
            return;
        }

        if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendLowStockSms(itemName, quantity);
        } else {
            pendingAlertItem = itemName;
            pendingAlertQuantity = quantity;
            requestSmsPermission();
        }
    }

    private void sendLowStockSms(String itemName, int quantity) {
        String phone = databaseHelper.getPhone(userId);
        if (phone.isEmpty()) {
            return;
        }

        String message = "Inventory alert: " + itemName + " is low. Current quantity: " + quantity + ".";
        try {
            SmsManager smsManager = getSystemService(SmsManager.class);
            if (smsManager == null) {
                throw new IllegalStateException("SMS service unavailable");
            }
            smsManager.sendTextMessage(phone, null, message, null, null);
            Toast.makeText(this, "Low-stock SMS sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS could not be sent. Inventory is still available.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != SMS_PERMISSION_REQUEST) {
            return;
        }

        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS alerts enabled.", Toast.LENGTH_SHORT).show();
            if (!pendingAlertItem.isEmpty() && pendingAlertQuantity >= 0) {
                sendLowStockSms(pendingAlertItem, pendingAlertQuantity);
            }
        } else {
            Toast.makeText(this, "SMS denied. Inventory features will continue to work.", Toast.LENGTH_LONG).show();
        }
        pendingAlertItem = "";
        pendingAlertQuantity = -1;
    }

    private void logOut() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
