package com.example.cs360inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory_manager.db";
    private static final int DATABASE_VERSION = 1;
    private static final String USER_TABLE = "users";
    private static final String INVENTORY_TABLE = "inventory";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + USER_TABLE + " (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, phone TEXT NOT NULL)");
        db.execSQL("CREATE TABLE " + INVENTORY_TABLE + " (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, item_name TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + INVENTORY_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        onCreate(db);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    public long createUser(String username, String password, String phone) {
        ContentValues values = new ContentValues();
        values.put("username", username.trim());
        values.put("password_hash", hashPassword(password));
        values.put("phone", phone.trim());
        return getWritableDatabase().insert(USER_TABLE, null, values);
    }

    public long authenticateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(
                USER_TABLE,
                new String[]{"id"},
                "username = ? AND password_hash = ?",
                new String[]{username.trim(), hashPassword(password)},
                null,
                null,
                null)) {
            if (cursor.moveToFirst()) {
                return cursor.getLong(cursor.getColumnIndexOrThrow("id"));
            }
        }
        return -1;
    }

    public String getUsername(long userId) {
        return getUserField(userId, "username");
    }

    public String getPhone(long userId) {
        return getUserField(userId, "phone");
    }

    private String getUserField(long userId, String field) {
        try (Cursor cursor = getReadableDatabase().query(
                USER_TABLE,
                new String[]{field},
                "id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                null)) {
            if (cursor.moveToFirst()) {
                return cursor.getString(cursor.getColumnIndexOrThrow(field));
            }
        }
        return "";
    }

    public long addInventoryItem(long userId, String name, int quantity) {
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("item_name", name.trim());
        values.put("quantity", quantity);
        return getWritableDatabase().insert(INVENTORY_TABLE, null, values);
    }

    public boolean updateInventoryItem(long itemId, long userId, String name, int quantity) {
        ContentValues values = new ContentValues();
        values.put("item_name", name.trim());
        values.put("quantity", quantity);
        int rows = getWritableDatabase().update(
                INVENTORY_TABLE,
                values,
                "id = ? AND user_id = ?",
                new String[]{String.valueOf(itemId), String.valueOf(userId)});
        return rows > 0;
    }

    public boolean deleteInventoryItem(long itemId, long userId) {
        int rows = getWritableDatabase().delete(
                INVENTORY_TABLE,
                "id = ? AND user_id = ?",
                new String[]{String.valueOf(itemId), String.valueOf(userId)});
        return rows > 0;
    }

    public List<InventoryItem> getInventoryItems(long userId) {
        List<InventoryItem> items = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(
                INVENTORY_TABLE,
                new String[]{"id", "item_name", "quantity"},
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                "item_name COLLATE NOCASE ASC")) {
            while (cursor.moveToNext()) {
                items.add(new InventoryItem(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("item_name")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("quantity"))));
            }
        }
        return items;
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            for (byte value : hash) {
                builder.append(String.format("%02x", value));
            }
            return builder.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
