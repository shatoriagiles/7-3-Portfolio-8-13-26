package com.example.cs360inventory;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends Activity {
    private DatabaseHelper databaseHelper;
    private EditText usernameInput;
    private EditText passwordInput;
    private EditText phoneInput;
    private TextView loginMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new DatabaseHelper(this);
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        phoneInput = findViewById(R.id.phoneInput);
        loginMessage = findViewById(R.id.loginMessage);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        loginButton.setOnClickListener(view -> logIn());
        createAccountButton.setOnClickListener(view -> createAccount());
    }

    private void logIn() {
        String username = usernameInput.getText().toString();
        String password = passwordInput.getText().toString();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            loginMessage.setText("Enter your username and password.");
            return;
        }

        long userId = databaseHelper.authenticateUser(username, password);
        if (userId < 0) {
            loginMessage.setText("Username or password is incorrect.");
            return;
        }

        openInventory(userId);
    }

    private void createAccount() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();
        String phone = phoneInput.getText().toString().trim();

        if (username.length() < 3) {
            loginMessage.setText("Username must contain at least 3 characters.");
            return;
        }

        if (password.length() < 4) {
            loginMessage.setText("Password must contain at least 4 characters.");
            return;
        }

        if (phone.length() < 7) {
            loginMessage.setText("Enter a phone number for inventory alerts.");
            return;
        }

        long userId = databaseHelper.createUser(username, password, phone);
        if (userId < 0) {
            loginMessage.setText("That username already exists.");
            return;
        }

        openInventory(userId);
    }

    private void openInventory(long userId) {
        Intent intent = new Intent(this, InventoryActivity.class);
        intent.putExtra("userId", userId);
        startActivity(intent);
        finish();
    }
}
